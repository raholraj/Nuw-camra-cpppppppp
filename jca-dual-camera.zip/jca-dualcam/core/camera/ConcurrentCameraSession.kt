/*
 * Copyright (C) 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.jetpackcamera.core.camera

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.camera.core.CameraState as CXCameraState
import androidx.camera.core.CompositionSettings
import androidx.camera.core.TorchState
import androidx.camera.core.UseCaseGroup
import androidx.lifecycle.asFlow
import com.google.jetpackcamera.model.CaptureMode
import com.google.jetpackcamera.model.DualRecordingMode
import com.google.jetpackcamera.model.DynamicRange
import com.google.jetpackcamera.model.ImageOutputFormat
import com.google.jetpackcamera.model.StabilizationMode
import com.google.jetpackcamera.model.TARGET_FPS_AUTO
import com.google.jetpackcamera.model.VideoQuality
import com.google.jetpackcamera.settings.model.CameraConstraints
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

private const val TAG = "ConcurrentCameraSession"

context(CameraSessionContext)
@SuppressLint("RestrictedApi")
internal suspend fun runConcurrentCameraSession(
    sessionSettings: PerpetualSessionSettings.ConcurrentCamera,
    cameraConstraints: CameraConstraints?
) = coroutineScope {
    val primaryLensFacing = sessionSettings.primaryCameraInfo.appLensFacing
    val secondaryLensFacing = sessionSettings.secondaryCameraInfo.appLensFacing
    Log.d(
        TAG,
        "Starting concurrent camera session " +
            "[primary: $primaryLensFacing, secondary: $secondaryLensFacing, " +
            "mode: ${sessionSettings.dualRecordingMode}]"
    )

    when (sessionSettings.dualRecordingMode) {
        DualRecordingMode.PIP -> runCompositedConcurrentSession(
            sessionSettings = sessionSettings,
            cameraConstraints = cameraConstraints,
            primaryComposition = CompositionSettings.Builder()
                .setAlpha(1.0f)
                .setOffset(0.0f, 0.0f)
                .setScale(1.0f, 1.0f)
                .build(),
            secondaryComposition = CompositionSettings.Builder()
                .setAlpha(1.0f)
                .setOffset(2 / 3f - 0.1f, -2 / 3f + 0.1f)
                .setScale(1 / 3f, 1 / 3f)
                .build()
        )

        DualRecordingMode.SIDE_BY_SIDE -> runCompositedConcurrentSession(
            sessionSettings = sessionSettings,
            cameraConstraints = cameraConstraints,
            // Primary occupies left half, secondary occupies right half.
            // CameraX CompositionSettings offsets are in normalised [-1, 1] clip space.
            primaryComposition = CompositionSettings.Builder()
                .setAlpha(1.0f)
                .setOffset(-0.5f, 0.0f)
                .setScale(0.5f, 1.0f)
                .build(),
            secondaryComposition = CompositionSettings.Builder()
                .setAlpha(1.0f)
                .setOffset(0.5f, 0.0f)
                .setScale(0.5f, 1.0f)
                .build()
        )

        DualRecordingMode.SEPARATE_FILES -> runSeparateFilesConcurrentSession(
            sessionSettings = sessionSettings,
            cameraConstraints = cameraConstraints
        )
    }
}

// ---------------------------------------------------------------------------
// Shared composited path (PIP + SIDE_BY_SIDE)
// Both cameras feed into a single composited VideoCapture via CompositionSettings.
// ---------------------------------------------------------------------------

context(CameraSessionContext)
@SuppressLint("RestrictedApi")
private suspend fun runCompositedConcurrentSession(
    sessionSettings: PerpetualSessionSettings.ConcurrentCamera,
    cameraConstraints: CameraConstraints?,
    primaryComposition: CompositionSettings,
    secondaryComposition: CompositionSettings
) = coroutineScope {
    val initialTransientSettings = transientSettings.filterNotNull().first()

    val videoCapture = if (sessionSettings.captureMode != CaptureMode.IMAGE_ONLY) {
        createVideoUseCase(
            cameraProvider.getCameraInfo(
                initialTransientSettings.primaryLensFacing.toCameraSelector()
            ),
            sessionSettings.aspectRatio,
            TARGET_FPS_AUTO,
            StabilizationMode.OFF,
            DynamicRange.SDR,
            VideoQuality.UNSPECIFIED,
            backgroundDispatcher
        )
    } else {
        null
    }

    val useCaseGroup = createUseCaseGroup(
        cameraInfo = sessionSettings.primaryCameraInfo,
        initialTransientSettings = initialTransientSettings,
        stabilizationMode = StabilizationMode.OFF,
        aspectRatio = sessionSettings.aspectRatio,
        imageFormat = ImageOutputFormat.JPEG,
        captureMode = sessionSettings.captureMode,
        videoCaptureUseCase = videoCapture
    )

    val cameraConfigs = listOf(
        Pair(sessionSettings.primaryCameraInfo.cameraSelector, primaryComposition),
        Pair(sessionSettings.secondaryCameraInfo.cameraSelector, secondaryComposition)
    )

    cameraProvider.runWithConcurrent(cameraConfigs, useCaseGroup) { concurrentCamera ->
        Log.d(TAG, "Composited concurrent camera session started")
        val primaryCamera = concurrentCamera.cameras.first {
            it.cameraInfo.appLensFacing == sessionSettings.primaryCameraInfo.appLensFacing
        }

        launch { processFocusMeteringEvents(primaryCamera.cameraInfo, primaryCamera.cameraControl) }
        launch { processVideoControlEvents(useCaseGroup.getVideoCapture(), captureTypeSuffix = "DualCam") }
        launch { observeTorchState(sessionSettings) }
        launch { observeCameraRunningState(primaryCamera) }
        launch { observeZoomState(primaryCamera) }

        applyDeviceRotation(initialTransientSettings.deviceRotation, useCaseGroup)
        processTransientSettingEvents(
            primaryCamera,
            cameraConstraints,
            useCaseGroup,
            initialTransientSettings,
            transientSettings,
            null
        )
    }
}

// ---------------------------------------------------------------------------
// SEPARATE_FILES path
// Primary camera gets Preview + VideoCapture; secondary gets its own VideoCapture only.
// Both recordings share a timestamp suffix so they can be matched after the fact.
// ---------------------------------------------------------------------------

context(CameraSessionContext)
@SuppressLint("RestrictedApi")
private suspend fun runSeparateFilesConcurrentSession(
    sessionSettings: PerpetualSessionSettings.ConcurrentCamera,
    cameraConstraints: CameraConstraints?
) = coroutineScope {
    val initialTransientSettings = transientSettings.filterNotNull().first()

    // --- Primary: Preview + VideoCapture ---
    val primaryVideoCapture = createVideoUseCase(
        cameraProvider.getCameraInfo(
            sessionSettings.primaryCameraInfo.cameraSelector
        ),
        sessionSettings.aspectRatio,
        TARGET_FPS_AUTO,
        StabilizationMode.OFF,
        DynamicRange.SDR,
        VideoQuality.UNSPECIFIED,
        backgroundDispatcher
    )

    val primaryUseCaseGroup = createUseCaseGroup(
        cameraInfo = sessionSettings.primaryCameraInfo,
        initialTransientSettings = initialTransientSettings,
        stabilizationMode = StabilizationMode.OFF,
        aspectRatio = sessionSettings.aspectRatio,
        imageFormat = ImageOutputFormat.JPEG,
        captureMode = sessionSettings.captureMode,
        videoCaptureUseCase = primaryVideoCapture
    )

    // --- Secondary: VideoCapture only (no Preview — primary owns the viewfinder surface) ---
    val secondaryVideoCapture = createVideoUseCase(
        cameraProvider.getCameraInfo(
            sessionSettings.secondaryCameraInfo.cameraSelector
        ),
        sessionSettings.aspectRatio,
        TARGET_FPS_AUTO,
        StabilizationMode.OFF,
        DynamicRange.SDR,
        VideoQuality.UNSPECIFIED,
        backgroundDispatcher
    )

    val secondaryUseCaseGroup = UseCaseGroup.Builder()
        .addUseCase(secondaryVideoCapture)
        .build()

    // Full-screen CompositionSettings for each camera independently.
    val fullScreen = CompositionSettings.Builder()
        .setAlpha(1.0f)
        .setOffset(0.0f, 0.0f)
        .setScale(1.0f, 1.0f)
        .build()

    cameraProvider.runWithConcurrentPerCamera(
        primaryConfig = Triple(
            sessionSettings.primaryCameraInfo.cameraSelector,
            primaryUseCaseGroup,
            fullScreen
        ),
        secondaryConfig = Triple(
            sessionSettings.secondaryCameraInfo.cameraSelector,
            secondaryUseCaseGroup,
            fullScreen
        )
    ) { concurrentCamera ->
        Log.d(TAG, "Separate-files concurrent camera session started")
        val primaryCamera = concurrentCamera.cameras.first {
            it.cameraInfo.appLensFacing == sessionSettings.primaryCameraInfo.appLensFacing
        }

        launch { processFocusMeteringEvents(primaryCamera.cameraInfo, primaryCamera.cameraControl) }

        // Fan-out the single videoCaptureControlEvents channel to both recordings.
        // The secondary recording mirrors the primary's start/stop/pause/resume events.
        launch {
            processDualVideoControlEvents(
                primaryVideoCapture = primaryVideoCapture,
                secondaryVideoCapture = secondaryVideoCapture
            )
        }

        launch { observeTorchState(sessionSettings) }
        launch { observeCameraRunningState(primaryCamera) }
        launch { observeZoomState(primaryCamera) }

        applyDeviceRotation(initialTransientSettings.deviceRotation, primaryUseCaseGroup)
        processTransientSettingEvents(
            primaryCamera,
            cameraConstraints,
            primaryUseCaseGroup,
            initialTransientSettings,
            transientSettings,
            null
        )
    }
}

// ---------------------------------------------------------------------------
// Dual recording control — fans a single event channel to two VideoCaptures.
// ---------------------------------------------------------------------------

context(CameraSessionContext)
@SuppressLint("RestrictedApi")
internal suspend fun processDualVideoControlEvents(
    primaryVideoCapture: VideoCapture<Recorder>,
    secondaryVideoCapture: VideoCapture<Recorder>
) = coroutineScope {
    for (event in videoCaptureControlEvents) {
        when (event) {
            is VideoCaptureControlEvent.StartRecordingEvent -> {
                runDualVideoRecording(
                    primaryVideoCapture = primaryVideoCapture,
                    secondaryVideoCapture = secondaryVideoCapture,
                    saveLocation = event.saveLocation,
                    maxVideoDuration = event.maxVideoDuration,
                    onVideoRecord = event.onVideoRecord
                )
            }
            else -> {} // Ignored outside of an active recording — handled inside runDualVideoRecording.
        }
    }
}

context(CameraSessionContext)
@SuppressLint("RestrictedApi")
private suspend fun runDualVideoRecording(
    primaryVideoCapture: VideoCapture<Recorder>,
    secondaryVideoCapture: VideoCapture<Recorder>,
    saveLocation: com.google.jetpackcamera.model.SaveLocation,
    maxVideoDuration: Long,
    onVideoRecord: (OnVideoRecordEvent) -> Unit
) = coroutineScope {
    // Shared timestamp suffix so both clips can be paired after the fact.
    val sharedTimestamp = System.currentTimeMillis().toString()

    val primaryPending = getPendingRecording(
        context,
        primaryVideoCapture,
        maxVideoDuration,
        filePathGenerator,
        captureTypeSuffix = "Primary_$sharedTimestamp",
        saveLocation,
        onVideoRecord
    ) ?: return@coroutineScope

    val secondaryPending = getPendingRecording(
        context,
        secondaryVideoCapture,
        maxVideoDuration,
        filePathGenerator,
        captureTypeSuffix = "Secondary_$sharedTimestamp",
        saveLocation,
        // Secondary errors are logged but don't surface to the primary callback.
        onVideoRecord = { evt ->
            if (evt is OnVideoRecordEvent.OnVideoRecordError) {
                Log.e(TAG, "Secondary recording error: ${evt.error}", evt.error)
            }
        }
    ) ?: return@coroutineScope

    val currentSettings = transientSettings.filterNotNull().first()

    startVideoRecordingInternal(
        context = context,
        pendingRecord = primaryPending,
        maxDurationMillis = maxVideoDuration,
        onVideoRecord = onVideoRecord,
        initialRecordingSettings = InitialRecordingSettings(
            isAudioEnabled = currentSettings.isAudioEnabled,
            lensFacing = currentSettings.primaryLensFacing,
            zoomRatios = currentSettings.zoomRatios
        )
    ).use { primaryRecording ->
        startVideoRecordingInternal(
            context = context,
            pendingRecord = secondaryPending,
            maxDurationMillis = maxVideoDuration,
            onVideoRecord = { /* secondary events are dropped */ },
            initialRecordingSettings = InitialRecordingSettings(
                isAudioEnabled = currentSettings.isAudioEnabled,
                lensFacing = currentSettings.primaryLensFacing,
                zoomRatios = currentSettings.zoomRatios
            )
        ).use { secondaryRecording ->
            val audioUpdater = launch {
                transientSettings.filterNotNull().collectLatest { newSettings ->
                    val muted = !newSettings.isAudioEnabled
                    primaryRecording.mute(muted)
                    secondaryRecording.mute(muted)
                }
            }

            for (event in videoCaptureControlEvents) {
                when (event) {
                    is VideoCaptureControlEvent.StartRecordingEvent ->
                        Log.w(TAG, "Recording already in progress, ignoring StartRecordingEvent")

                    VideoCaptureControlEvent.StopRecordingEvent -> {
                        audioUpdater.cancel()
                        break
                    }

                    VideoCaptureControlEvent.PauseRecordingEvent -> {
                        primaryRecording.pause()
                        secondaryRecording.pause()
                    }

                    VideoCaptureControlEvent.ResumeRecordingEvent -> {
                        primaryRecording.resume()
                        secondaryRecording.resume()
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Shared observer helpers (extracted to avoid duplication between paths)
// ---------------------------------------------------------------------------

context(CameraSessionContext)
private suspend fun observeTorchState(sessionSettings: PerpetualSessionSettings.ConcurrentCamera) {
    sessionSettings.primaryCameraInfo.torchState.asFlow().collectLatest { torchState ->
        currentCameraState.update { old ->
            old.copy(isTorchEnabled = torchState == TorchState.ON)
        }
    }
}

context(CameraSessionContext)
private suspend fun observeCameraRunningState(
    primaryCamera: androidx.camera.core.Camera
) {
    primaryCamera.cameraInfo.cameraState
        .asFlow()
        .filterNotNull()
        .distinctUntilChanged()
        .onCompletion {
            currentCameraState.update { old -> old.copy(isCameraRunning = false) }
        }
        .collectLatest { cameraState ->
            currentCameraState.update { old ->
                old.copy(isCameraRunning = cameraState.type == CXCameraState.Type.OPEN)
            }
        }
}

context(CameraSessionContext)
private suspend fun observeZoomState(primaryCamera: androidx.camera.core.Camera) {
    primaryCamera.cameraInfo.zoomState.asFlow().filterNotNull().distinctUntilChanged()
        .collectLatest { zoomState ->
            val settings = transientSettings.value
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                if (zoomState.zoomRatio != 1.0f ||
                    settings == null ||
                    zoomState.zoomRatio ==
                    settings.zoomRatios[primaryCamera.cameraInfo.appLensFacing]
                ) {
                    currentCameraState.update { old ->
                        old.copy(
                            zoomRatios = old.zoomRatios.toMutableMap().apply {
                                put(primaryCamera.cameraInfo.appLensFacing, zoomState.zoomRatio)
                            }.toMap(),
                            linearZoomScales = old.linearZoomScales.toMutableMap().apply {
                                put(
                                    primaryCamera.cameraInfo.appLensFacing,
                                    zoomState.linearZoom
                                )
                            }.toMap()
                        )
                    }
                }
            }
        }
}
