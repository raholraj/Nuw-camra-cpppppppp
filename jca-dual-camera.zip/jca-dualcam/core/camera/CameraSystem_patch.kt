// FILE: core/camera/src/main/java/com/google/jetpackcamera/core/camera/CameraSystem.kt
// ADD this method to the CameraSystem interface, directly after setConcurrentCameraMode:

    /**
     * Sets the recording mode to use when dual (concurrent) camera mode is active.
     *
     * Calling this outside of concurrent-camera mode has no immediate effect; the value will
     * be applied the next time a concurrent session is started.
     *
     * @param mode The [DualRecordingMode] to apply.
     */
    suspend fun setDualRecordingMode(mode: com.google.jetpackcamera.model.DualRecordingMode)
