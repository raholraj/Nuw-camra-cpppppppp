// FILE: core/camera/src/main/java/com/google/jetpackcamera/core/camera/CameraXCameraSystem.kt
//
// CHANGE 1 — In the ConcurrentCameraMode.DUAL branch (~line 467),
// pass dualRecordingMode when constructing PerpetualSessionSettings.ConcurrentCamera:
//
//   PerpetualSessionSettings.ConcurrentCamera(
//       primaryCameraInfo = nonNullPrimary,
//       secondaryCameraInfo = nonNullSecondary,
//       aspectRatio = currentCameraSettings.aspectRatio,
//       dualRecordingMode = currentCameraSettings.dualRecordingMode   // ← ADD THIS LINE
//   )
//
// CHANGE 2 — Add this method near setConcurrentCameraMode (~line 989):

    override suspend fun setDualRecordingMode(mode: com.google.jetpackcamera.model.DualRecordingMode) {
        currentSettings.update { old ->
            old?.copy(dualRecordingMode = mode)
        }
    }
