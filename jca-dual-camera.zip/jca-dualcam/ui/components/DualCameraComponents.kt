/*
 * Copyright (C) 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.jetpackcamera.ui.components.capture

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.Duo
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.PictureInPicture
import androidx.compose.material.icons.outlined.VideoFile
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.google.jetpackcamera.model.DualRecordingMode
import kotlin.math.roundToInt

// ─── Dual Camera Mode Button ──────────────────────────────────────────────────

/**
 * Icon button that opens the dual-camera recording mode picker.
 *
 * Should only be rendered while [ConcurrentCameraMode.DUAL] is active.
 *
 * @param currentMode The mode currently in effect (used to show a visual hint).
 * @param enabled Whether the button is interactive. Pass `false` while recording to prevent
 *   mid-recording mode switches (the mode change takes effect on the *next* recording).
 * @param onClick Called when the button is tapped.
 */
@Composable
fun DualCameraButton(
    currentMode: DualRecordingMode,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    IconButton(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled
    ) {
        Icon(
            imageVector = currentMode.icon(),
            contentDescription = "Dual camera recording mode: ${currentMode.label()}",
            tint = if (enabled) Color.White else Color.White.copy(alpha = 0.4f)
        )
    }
}

// ─── Mode Picker Bottom Sheet ─────────────────────────────────────────────────

/**
 * Modal bottom sheet that lets the user pick among [DualRecordingMode] options.
 *
 * Dismiss the sheet by calling [onDismiss] or tapping outside.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DualCameraModePicker(
    currentMode: DualRecordingMode,
    onModeSelected: (DualRecordingMode) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        modifier = modifier
    ) {
        Text(
            text = "Dual Camera Recording Mode",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )

        DualRecordingMode.entries.forEach { mode ->
            ListItem(
                headlineContent = {
                    Text(text = mode.label())
                },
                supportingContent = {
                    Text(text = mode.description())
                },
                leadingContent = {
                    Icon(
                        imageVector = mode.icon(),
                        contentDescription = null
                    )
                },
                trailingContent = if (mode == currentMode) {
                    {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = "Selected",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                } else {
                    null
                },
                modifier = Modifier.clickable {
                    onModeSelected(mode)
                    onDismiss()
                }
            )
        }

        Spacer(Modifier.padding(bottom = 16.dp))
    }
}

// ─── Draggable / Resizable PIP Overlay ───────────────────────────────────────

/**
 * A semi-transparent overlay box representing the front-camera feed in PIP mode.
 *
 * The box is **draggable** anywhere on the viewfinder surface and **resizable** via a
 * two-finger pinch gesture. Size is clamped between 15 % and 45 % of the screen width so
 * the overlay never obscures too much of the primary feed or becomes too small to see.
 *
 * **Important:** this composable controls the *viewfinder display* only. The recorded video
 * uses the fixed [CompositionSettings] PIP layout set in [ConcurrentCameraSession]; these
 * two are independent so that dragging/resizing feels instant with zero encode overhead.
 *
 * @param visible Whether to render the overlay at all. Set to `false` when concurrent camera
 *   is off or when [DualRecordingMode] is not [DualRecordingMode.PIP].
 */
@Composable
fun DraggablePipOverlay(
    visible: Boolean,
    modifier: Modifier = Modifier
) {
    if (!visible) return

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val density = LocalDensity.current

        // Size bounds in dp, computed once from the available width.
        val minSizeDp: Dp = maxWidth * 0.15f
        val maxSizeDp: Dp = maxWidth * 0.45f
        val initialSizeDp: Dp = maxWidth * 0.28f

        // Convert to px for offset arithmetic.
        val minSizePx = with(density) { minSizeDp.toPx() }
        val maxSizePx = with(density) { maxSizeDp.toPx() }
        val initialSizePx = with(density) { initialSizeDp.toPx() }
        val screenWidthPx = with(density) { maxWidth.toPx() }
        val screenHeightPx = with(density) { maxHeight.toPx() }

        // Mutable state — survives recompositions within this scope.
        var pipSizePx by remember { mutableStateOf(initialSizePx) }
        var pipOffset by remember {
            mutableStateOf(
                // Default: top-right corner with a small margin.
                Offset(
                    x = screenWidthPx - initialSizePx - with(density) { 16.dp.toPx() },
                    y = with(density) { 16.dp.toPx() }
                )
            )
        }

        // Combined drag + pinch-to-resize handler running on a dedicated input thread.
        val gestureModifier = Modifier.pointerInput(Unit) {
            detectTransformGestures { _, pan, zoom, _ ->
                // --- Resize ---
                val newSize = (pipSizePx * zoom).coerceIn(minSizePx, maxSizePx)
                pipSizePx = newSize

                // --- Drag ---
                val newX = (pipOffset.x + pan.x).coerceIn(0f, screenWidthPx - pipSizePx)
                val newY = (pipOffset.y + pan.y).coerceIn(0f, screenHeightPx - pipSizePx)
                pipOffset = Offset(newX, newY)
            }
        }

        val pipSizeDp: Dp = with(density) { pipSizePx.toDp() }

        Box(
            modifier = Modifier
                .offset {
                    IntOffset(pipOffset.x.roundToInt(), pipOffset.y.roundToInt())
                }
                .size(pipSizeDp)
                .clip(RoundedCornerShape(8.dp))
                .border(
                    width = 2.dp,
                    color = Color.White.copy(alpha = 0.8f),
                    shape = RoundedCornerShape(8.dp)
                )
                .background(Color.Black.copy(alpha = 0.25f))
                .then(gestureModifier),
            contentAlignment = Alignment.Center
        ) {
            // Minimal label so the user knows this is the front-camera feed.
            // In a full implementation this Box would host a second SurfaceView/
            // AndroidExternalSurface bound to the secondary camera preview surface.
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Outlined.Duo,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "Front",
                    color = Color.White.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

// ─── Mode metadata helpers ────────────────────────────────────────────────────

private fun DualRecordingMode.label(): String = when (this) {
    DualRecordingMode.PIP -> "Picture-in-Picture"
    DualRecordingMode.SIDE_BY_SIDE -> "Side by Side"
    DualRecordingMode.SEPARATE_FILES -> "Separate Files"
}

private fun DualRecordingMode.description(): String = when (this) {
    DualRecordingMode.PIP ->
        "Front camera overlaid on back camera. Drag & resize the overlay in the viewfinder."
    DualRecordingMode.SIDE_BY_SIDE ->
        "Both cameras recorded in a 50/50 split into one file."
    DualRecordingMode.SEPARATE_FILES ->
        "Each camera saved as its own .mp4 with a shared timestamp in the filename."
}

private fun DualRecordingMode.icon(): ImageVector = when (this) {
    DualRecordingMode.PIP -> Icons.Outlined.PictureInPicture
    DualRecordingMode.SIDE_BY_SIDE -> Icons.Outlined.GridView
    DualRecordingMode.SEPARATE_FILES -> Icons.Outlined.VideoFile
}
