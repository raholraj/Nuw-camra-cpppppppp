# JCA Dual-Camera Recording — Implementation Package

This package contains all **new and modified files** for the dual-camera recording feature
added to Google's Jetpack Camera App (JCA).

---

## File Map

```
.github/workflows/build.yml                  NEW  GitHub Actions — builds debug APK on push
core/model/DualRecordingMode.kt              NEW  Enum: PIP | SIDE_BY_SIDE | SEPARATE_FILES
core/camera/CoroutineCameraProvider.kt       MOD  Added runWithConcurrentPerCamera()
core/camera/CameraSessionSettings.kt         MOD  Added dualRecordingMode to ConcurrentCamera
core/camera/ConcurrentCameraSession.kt       MOD  Full mode-aware session logic
core/camera/CameraSystem_patch.kt            NOTE add setDualRecordingMode() to interface
core/camera/CameraXCameraSystem_patch.kt     NOTE two-line changes to CameraXCameraSystem
core/camera/FakeCameraSystem_patch.kt        NOTE stub override for tests
core/settings/CameraAppSettings_patch.kt     NOTE add dualRecordingMode field + import
ui/controller/DualCameraController.kt        NEW  Interface
ui/controller/DualCameraControllerImpl.kt    NEW  Implementation (wraps CameraSystem)
ui/components/DualCameraComponents.kt        NEW  DualCameraButton, ModePicker, DraggablePipOverlay
ui/components/CaptureLayout.kt               MOD  Added dualCameraButton + pipOverlay slots
feature/preview/PreviewScreen_patch.md       NOTE step-by-step diff for PreviewScreen + ViewModel
```

---

## How to Apply

### Step 1 — Copy new files verbatim

Copy the following files into the JCA source tree, preserving the package structure shown
in each file's `package` declaration:

| File in this package | Destination in JCA |
|---|---|
| `core/model/DualRecordingMode.kt` | `core/model/src/main/java/com/google/jetpackcamera/model/` |
| `core/camera/CoroutineCameraProvider.kt` | `core/camera/src/main/java/com/google/jetpackcamera/core/camera/` (replace) |
| `core/camera/CameraSessionSettings.kt` | same dir (replace) |
| `core/camera/ConcurrentCameraSession.kt` | same dir (replace) |
| `ui/controller/DualCameraController.kt` | `ui/controller/src/main/java/com/google/jetpackcamera/ui/controller/` |
| `ui/controller/DualCameraControllerImpl.kt` | `ui/controller/impl/src/main/java/com/google/jetpackcamera/ui/controller/impl/` |
| `ui/components/DualCameraComponents.kt` | `ui/components/capture/src/main/java/com/google/jetpackcamera/ui/components/capture/` |
| `ui/components/CaptureLayout.kt` | same dir (replace) |
| `.github/workflows/build.yml` | `.github/workflows/` |

### Step 2 — Apply patch notes

Each `*_patch.kt` / `*_patch.md` file contains a clear description of the small edits
needed to existing files. They are **not** drop-in replacements — follow the instructions
inside each one:

| Patch note | Target file |
|---|---|
| `core/camera/CameraSystem_patch.kt` | `core/camera/.../CameraSystem.kt` |
| `core/camera/CameraXCameraSystem_patch.kt` | `core/camera/.../CameraXCameraSystem.kt` |
| `core/camera/FakeCameraSystem_patch.kt` | `core/camera/testing/.../FakeCameraSystem.kt` |
| `core/settings/CameraAppSettings_patch.kt` | `core/settings/.../CameraAppSettings.kt` |
| `feature/preview/PreviewScreen_patch.md` | `feature/preview/.../PreviewScreen.kt` **and** `PreviewViewModel.kt` |

### Step 3 — Format

Run Spotless before committing or CI will fail:

```bash
./gradlew spotlessApply --init-script gradle/init.gradle.kts
```

### Step 4 — Build

```bash
./gradlew assembleStableDebug
```

Or push to GitHub and the new `build.yml` workflow will produce a downloadable APK artifact.

---

## Architecture Notes

### PIP & Side-by-Side
Both modes reuse the **existing** `CompositionSettings` compositing path — the primary and
secondary cameras are composited at the driver level into a single shared surface, and
`VideoCapture` records that surface. No extra CPU/GPU overhead is introduced.

The `DraggablePipOverlay` composable is a **preview-only** UI affordance. It is rendered
on the Compose layer above the viewfinder and uses `pointerInput { detectTransformGestures }`
for gesture handling entirely on Compose's input thread. It does not affect the recorded
video output.

### Separate Files
`runWithConcurrentPerCamera()` (new in `CoroutineCameraProvider.kt`) passes each camera
its **own** `UseCaseGroup`:
- Primary gets `Preview + VideoCapture` (viewfinder + recording).
- Secondary gets `VideoCapture` only (recording only — no second viewfinder surface needed).

`processDualVideoControlEvents()` fans the single `videoCaptureControlEvents` channel to
both `VideoCapture` instances. Both recordings start/stop/pause/resume together. They share
a `System.currentTimeMillis()` timestamp suffix in their filenames.

### Mid-recording toggle
The `DualCameraButton` is disabled while `VideoRecordingState.Active` to prevent a broken
mid-clip switch. Architectural support for a *live* mode toggle would require gating on a
second `MutableStateFlow<DualRecordingMode>` observed inside `runConcurrentCameraSession`;
that is left as a follow-up (see TODO in `ConcurrentCameraSession.kt`).

### Graceful fallback
The existing `tryApplyConcurrentCameraModeConstraints()` check in `CameraXCameraSystem`
already blocks concurrent mode on devices where `availableConcurrentCameraInfos` does not
include a front+back pair. `DualCameraButton` is conditioned on `isDualCamActive`, so it
simply does not render on those devices.

---

## Testing Checklist

- [ ] PIP: composited preview + single file recorded; PIP box drags/pinch-resizes smoothly
- [ ] Side-by-Side: preview and file show equal-split layout
- [ ] Separate Files: two `.mp4` files saved with matching `Primary_<ts>` / `Secondary_<ts>` suffixes
- [ ] Dual cam button hidden in single-camera (non-concurrent) mode
- [ ] Dual cam button disabled (grayed out) while recording is active
- [ ] All existing photo / single-camera video / zoom / flash features unaffected
- [ ] On a device without concurrent camera support: no crash, no dual cam button shown
